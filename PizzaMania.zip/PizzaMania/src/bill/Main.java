package bill;

import java.util.Scanner;

public class Main{

    public static  void main(String[] args) {
        System.out.println("_________________Welcome to PizzaMania_________________\n");
        System.out.println("which pizza: (1.veg 2.Non-Veg Pizza 3.Deluxe Veg Pizza 4.Deluxe Non-Veg Pizza) ===>");
        Scanner sc = new Scanner(System.in);
        int ch = sc.nextInt();
        switch (ch)
        {
            case 1:
                pizza vegPizza = new pizza(true);
                vegPizza.addExtraToppings();
                vegPizza.addExtraCheese();
                vegPizza.takeAway();
                vegPizza.getBill();
                break;
                case 2:
                    pizza nonVegPizza = new pizza(false);
                    nonVegPizza.addExtraToppings();
                    nonVegPizza.addExtraCheese();
                    nonVegPizza.takeAway();
                    nonVegPizza.getBill();
                    break;
                    case 3:
                        pizza deluxeVegPizza = new pizza(false);
                        deluxeVegPizza.addExtraToppings();
                        deluxeVegPizza.addExtraCheese();
                        deluxeVegPizza.takeAway();
                        deluxeVegPizza.getBill();
                        break;
                        case 4:
                            pizza deluxeNonVegPizza = new pizza(false);
                            deluxeNonVegPizza.addExtraToppings();
                            deluxeNonVegPizza.addExtraCheese();
                            deluxeNonVegPizza.takeAway();
                            deluxeNonVegPizza.getBill();
                            break;


        }
    }
}